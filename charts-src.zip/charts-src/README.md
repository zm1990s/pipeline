Pipeline Demo Application.
